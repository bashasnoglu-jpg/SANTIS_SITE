/* SANTIS SEO ARMOR - RICH SNIPPETS ENGINE */
/* Injects JSON-LD for Google Rich Results */

function injectServiceSchema(data) {
    // Remove existing schema if any to prevent duplicates on navigation
    const existing = document.getElementById('santis-json-ld');
    if (existing) existing.remove();

    const schemaData = {
        "@context": "https://schema.org/",
        "@type": "Service",
        "name": data.title,
        "description": data.desc,
        "provider": {
            "@type": "LocalBusiness",
            "name": "Santis Club Spa & Wellness",
            "image": "https://santisclub.com/assets/img/logo.png",
            "address": {
                "@type": "PostalAddress",
                "addressLocality": "Antalya",
                "addressCountry": "TR"
            },
            "telephone": "+905348350169",
            "priceRange": "$$$"
        },
        "areaServed": "Antalya",
        "offers": {
            "@type": "Offer",
            "priceCurrency": "EUR",
            "price": data.price || "0",
            "availability": "https://schema.org/InStock",
            "url": window.location.href
        }
    };

    const script = document.createElement('script');
    script.id = 'santis-json-ld';
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schemaData);
    document.head.appendChild(script);
    console.log("✅ SEO Armor: Rich Snippets Injected for " + data.title);
}

// Export globally
window.injectServiceSchema = injectServiceSchema;
