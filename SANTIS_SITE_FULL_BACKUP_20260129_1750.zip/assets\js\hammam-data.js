// assets/js/hammam-data.js
// SANTIS — Hammam dataset (Quiet Luxury Edition) v2.0
// Features: Absolute Paths, Fallback Guard, Evocative descriptions

(function () {
    // High-quality placeholders (Quiet Luxury style: dark, warm, minimal)
    // ROOT PATH FIX: Must start with / to work from subdirectories
    const IMG = {
        base: "/assets/img/cards/hamam.webp", // Safe fallback
        foam: "/assets/img/cards/hamam.webp",
        peeling: "/assets/img/cards/hamam.webp",
        ottoman: "/assets/img/cards/hamam.webp",
        coffee: "/assets/img/cards/hamam.webp",
        bridal: "/assets/img/cards/hamam.webp",
        pasha: "/assets/img/cards/hamam.webp"
    };

    window.NV_HAMMAM = [
        {
            id: "kese-kopuk",
            slug: "kese-kopuk",
            title: "Geleneksel Kese & Köpük",
            duration: "30 dk",
            price: null,
            tier: "CLASSIC",
            desc: "Sıcak mermer üzerinde başlayan arınma yolculuğu. Ölü deriden arındıran kese ve ipeksi köpük masajı ile cildiniz yeniden nefes alır.",
            img: IMG.peeling,
            category: "hammam",
            tags: ["kese", "köpük", "arınma"]
        },
        {
            id: "osmanli-ritueli",
            slug: "osmanli-ritueli",
            title: "Osmanlı Saray Ritüeli",
            duration: "50 dk",
            price: null,
            tier: "SIGNATURE",
            desc: "Sultanlara layık bir deneyim. Kese ve köpük seremonisine eşlik eden kil maskesi ve nemlendirici yağlar ile bedensel ve ruhsal bütünlük.",
            img: IMG.ottoman,
            category: "hammam",
            tags: ["lüks", "kil maskesi", "osmanlı"]
        },
        {
            id: "kahve-detox",
            slug: "kahve-detox",
            title: "Kahve Detox Arınma",
            duration: "45 dk",
            price: null,
            tier: "DETOX",
            desc: "Türk kahvesinin antioksidan gücüyle canlanın. Selülit karşıtı bakım ve derinlemesine arınma sağlayan özel bir ritüel.",
            img: IMG.coffee,
            category: "hammam",
            tags: ["detox", "kahve", "canlanma"]
        },
        {
            id: "santis-pasa",
            slug: "santis-pasa",
            title: "Santis Paşa Bakımı",
            duration: "60 dk",
            price: null,
            tier: "PREMIUM",
            desc: "Derinlemesine temizliğin ötesinde, baş masajı ve aromatik yağlarla zenginleştirilmiş, yorgunluğu silip atan uzun soluklu bir terapi.",
            img: IMG.pasha,
            category: "hammam",
            tags: ["masaj", "premium", "erkek"]
        },
        {
            id: "gelin-hamami",
            slug: "gelin-hamami",
            title: "Gelin Hamamı Seremonisi",
            duration: "120 dk",
            price: null,
            tier: "EVENT",
            desc: "En özel gününüz için hazırlanan, müzik, ikramlar ve geleneksel kutlamalarla dolu unutulmaz bir grup deneyimi.",
            img: IMG.bridal,
            category: "hammam",
            tags: ["gelin", "grup", "kutlama"]
        },
        {
            id: "kopuk-masaji",
            slug: "kopuk-masaji",
            title: "Sadece Köpük Masajı",
            duration: "20 dk",
            price: null,
            tier: "EXPRESS",
            desc: "Bulutların üzerinde yüzermişçesine hafifleten, sabun köpükleriyle yapılan nazik ve dinlendirici bir dokunuş.",
            img: IMG.foam,
            category: "hammam",
            tags: ["hızlı", "yumuşak", "köpük"]
        }
    ];

    // Placeholder Guard (Resim yüklenmezse devreye girer)
    window.NV_HAMMAM.forEach(item => {
        const imgCheck = new Image();
        imgCheck.onerror = () => {
            item.img = "/assets/img/luxury-placeholder.webp";
        };
        imgCheck.src = item.img;
    });

    console.log("✅ Hamam Data Loaded (Quiet Luxury Mode v2)");
})();
