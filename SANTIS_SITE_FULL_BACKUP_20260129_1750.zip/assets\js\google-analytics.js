/* Google Analytics 4 (GA4) Global Site Tag */
/* Bu dosya head etiketine eklenmelidir */

// <!-- Google tag (gtag.js) -->
// <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>

window.dataLayer = window.dataLayer || [];
function gtag() { dataLayer.push(arguments); }
gtag('js', new Date());

gtag('config', 'G-XXXXXXXXXX'); // G- Kodunuzu buraya yazın
