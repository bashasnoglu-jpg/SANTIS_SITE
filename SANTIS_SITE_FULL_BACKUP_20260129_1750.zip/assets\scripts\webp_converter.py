import os
from PIL import Image

def santis_webp_optimizer(folder_path):
    # Desteklenen lüks içerik formatları
    valid_extensions = ('.jpg', '.jpeg', '.png')
    
    # Klasör yoksa oluşturma veya kontrol etme
    if not os.path.exists(folder_path):
        print(f"Hata: {folder_path} yolu bulunamadı.")
        return

    for filename in os.listdir(folder_path):
        if filename.lower().endswith(valid_extensions):
            file_path = os.path.join(folder_path, filename)
            
            # Görseli aç
            with Image.open(file_path) as img:
                # Arka planı siyah olan PNG'ler için lüks doku koruması
                if img.mode in ("RGBA", "P"):
                    img = img.convert("RGB")
                
                # Çıktı adı
                target_name = os.path.splitext(filename)[0] + ".webp"
                target_path = os.path.join(folder_path, target_name)
                
                # Kaydet (Quiet Luxury Standartı: %85 kalite)
                img.save(target_path, "WEBP", quality=85, method=6)
                print(f"✓ {filename} -> {target_name} (Optimize edildi)")

# Scriptin bulunduğu klasörün bir üst seviyesindeki 'img' klasörünü hedefler
current_dir = os.path.dirname(os.path.abspath(__file__))
target_folder = os.path.join(current_dir, '..', 'img')

if os.path.exists(target_folder):
    print(f"📂 Hedef Klasör: {target_folder}")
    santis_webp_optimizer(target_folder)
else:
    print(f"❌ Klasör bulunamadı: {target_folder}. Lütfen assets/img yolunu kontrol edin.")
