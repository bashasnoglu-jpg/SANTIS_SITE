﻿// ===== Santis: TR-only mode (single source of truth) =====
const SITE_LANG = "tr";
window.SITE_LANG = SITE_LANG;

// URL'deki ?lang=... paramını kırmadan kaldır (back button bozulmasın)
(function normalizeLangParam() {
  try {
    const url = new URL(window.location.href);
    if (url.searchParams.has("lang")) {
      url.searchParams.delete("lang");
      history.replaceState({}, "", url.toString());
    }
  } catch (_) { }
})();

// db migrate (opsiyonel ama çok faydalı)
(function migrateDBtoTurkishOnly() {
  // Wait for window load or just check if DB exists (it might load after app.js if script order varies, 
  // but usually db.js loads before or after. safer to run this when accessed or try now if available)
  // Since db.js is often loaded before app.js, this should work.
  if (!Array.isArray(window.servicesDB)) return;

  window.servicesDB = window.servicesDB.map((s) => ({
    ...s,
    name: trText(s.name),
    desc: trText(s.desc),
  }));
})();

// Safe getter already exists below as trText, but we ensure it's global
window.trText = trText;

// Modal Helpers (Unified & Robust)
let __bookingLastFocus = null;

function openBookingModal() {
  const modal = document.getElementById("bookingModal");
  if (!modal) return;

  __bookingLastFocus = document.activeElement;

  // hidden attribute => görünür yap
  modal.hidden = false;

  // CSS'inle eşleşsin: .active kullanıyorsun
  modal.classList.add("active");

  // arka plan kilit
  document.body.style.overflow = "hidden";

  // arka planı inert yap (destek varsa)
  const main = document.getElementById("nv-main") || document.querySelector("main");
  if (main) main.setAttribute("inert", "");

  // Hide older specific alerts if they exist
  if (typeof hideAlert === 'function') {
    hideAlert("bookingAlert");
    hideAlert("formAlert");
  }

  // If these functions exist, run them
  if (typeof renderBookingUI === 'function') renderBookingUI();
  if (typeof updateWhatsappPreview === 'function') updateWhatsappPreview();

  // fokus
  setTimeout(() => {
    const focusEl =
      document.getElementById("bookHotel") ||
      modal.querySelector(".modal-close") ||
      modal.querySelector("button, [href], input, select, textarea");
    if (focusEl && typeof focusEl.focus === 'function') focusEl.focus();
  }, 0);

  window.addEventListener("keydown", escCloseOnce);
}

function closeBookingModal() {
  const modal = document.getElementById("bookingModal");
  if (!modal) return;

  modal.classList.remove("active");
  modal.hidden = true;

  document.body.style.overflow = "";

  const main = document.getElementById("nv-main") || document.querySelector("main");
  if (main) main.removeAttribute("inert");

  window.removeEventListener("keydown", escCloseOnce);

  // focus geri ver
  if (__bookingLastFocus && typeof __bookingLastFocus.focus === 'function') {
    __bookingLastFocus.focus();
  }
}

function escCloseOnce(e) {
  if (e.key === "Escape") closeBookingModal();
}

// dışarı tıkla kapat
document.addEventListener("mousedown", (e) => {
  const modal = document.getElementById("bookingModal");
  if (modal && !modal.hidden && e.target === modal) closeBookingModal();
});

const state = {
  lang: "tr",
  hotel: "",
  selectedServiceId: "",
  hotelFilter: "all",
  hotelSearch: "",
  activeCategoryId: "",
  serviceSearch: "",
  serviceSort: "relevance",
  onlyToday: false,
  durationQuick: "all",
  svcOpen: false,
  categoryView: "all"
};

let CONTENT = null;

// Helper to safely get Turkish text from legacy bilingual objects or new string fields
function trText(v) {
  if (!v) return "";
  if (typeof v === "string") return v;
  return v.tr || v.en || "";
}

function ensureSlug(svc) {
  if (!svc || svc.slug) return svc?.slug;

  const name = trText(svc.name) || String(svc.id || "");

  if (typeof window.slugifyTR === "function") {
    const s = window.slugifyTR(name);
    if (s) svc.slug = s;
  }

  if (!svc.slug && svc.id) svc.slug = String(svc.id);
  return svc.slug;
}

/* Core Helpers */
function t(path) {
  // If we have a global dictionary, look it up. 
  // We assume CONTENT is still loaded. If we flatten CONTENT later, this might simplify further.
  if (path.startsWith("booking.")) {
    const parts = path.split(".");
    let cur = CONTENT?.global?.booking?.translations?.tr; // Force TR
    for (let i = 1; i < parts.length; i++) cur = cur?.[parts[i]];
    if (cur !== undefined) return cur;
  }

  const parts = String(path || "").split(".");
  let cur = CONTENT?.tr; // Force TR
  for (const p of parts) cur = cur?.[p];
  return cur ?? path;
}

function getHotels() {
  return CONTENT?.global?.hotels || [];
}

function getSelectedHotel() {
  if (!state.hotel) return null;
  return getHotels().find(h => h.slug === state.hotel) || null;
}



/* Nav Helpers (New Logic) */

function getNavModel() {

  return CONTENT?.global?.navModel && Array.isArray(CONTENT.global.navModel)

    ? CONTENT.global.navModel

    : (window.NAV_MODEL || []);

}



function buildPrefix() {

  return "";

}



function buildUrl(routeKey, sectionKey) {

  if (window.DEMO_MODE) {

    return "#" + (sectionKey || routeKey);

  }



  const routes = CONTENT?.global?.routes || {};

  if (routes[routeKey]) return buildPrefix() + routes[routeKey];



  // Dynamic Routing (Query Params)

  if (sectionKey === 'booking') return "?section=booking";

  return "?view=" + routeKey;

}



function scrollToSection(sectionKey) {

  const target = document.querySelector(`[data-section="${sectionKey}"]`) || document.getElementById(sectionKey);

  if (target) {

    target.scrollIntoView({ behavior: "smooth", block: "start" });

  }

}



function scrollToId(id) {

  scrollToSection(id);

}



function setActiveCategoryFromRoute(routeKey) {

  const map = {

    hammam: "hammam",

    massages: "",

    classic: "classicMassages",

    sports: "sportsTherapy",

    asian: "asianMassages",

    ayurveda: "ayurveda",

    signature: "signatureCouples",

    kids: "kidsFamily",

    face: "faceSothys",

    products: "products"

  };

  const nextCat = map[routeKey];

  const catId = (nextCat !== undefined) ? nextCat : routeKey;



  if (!catId) return false;



  state.activeCategoryId = catId;

  return true;

}



function handleNavDemoClick(item) {

  if (item.categoryId) {

    state.activeCategoryId = item.categoryId;

    if (typeof renderCategoryToolbar === "function") renderCategoryToolbar();

    if (typeof renderCategories === "function") renderCategories();

    if (typeof renderServiceResults === "function") renderServiceResults();

  }

  const target = item.sectionKey || item.route;

  scrollToSection(target);

  history.replaceState(null, "", "#" + target);

}



/* Render Nav (New Version) */

function renderNav() {

  const root = document.getElementById("navRoot");

  if (!root) return;

  root.innerHTML = "";



  const model = getNavModel();



  for (const item of model) {

    if (item.enabled === false) continue;



    const div = document.createElement("div");

    const hasChildren = Array.isArray(item.children) && item.children.length > 0;

    div.className = "nav-item" + (hasChildren ? " has-sub" : "");



    const a = document.createElement("a");

    a.className = "nav-link";



    const sectionKey = item.sectionKey || item.route;

    a.href = buildUrl(item.route, sectionKey);

    a.textContent = t(`nav.${item.key}`) || item.label || item.key;



    if (window.DEMO_MODE) {

      a.onclick = (e) => {

        e.preventDefault();

        handleNavDemoClick(item);

      };

    }



    div.appendChild(a);



    if (hasChildren) {

      const menu = document.createElement("div");

      menu.className = "submenu";



      for (const ch of item.children) {

        const ca = document.createElement("a");

        const chSectionKey = ch.sectionKey || ch.route;

        ca.href = buildUrl(ch.route, chSectionKey);

        ca.textContent = t(`nav.${ch.key}`) || ch.label || ch.key;



        if (window.DEMO_MODE) {

          ca.onclick = (e) => {

            e.preventDefault();

            handleNavDemoClick(ch);

          };

        }

        menu.appendChild(ca);

      }

      div.appendChild(menu);

    }

    root.appendChild(div);

  }



  // CTA

  const cta = document.getElementById("ctaBooking");

  if (cta) {

    cta.textContent = t("nav.bookingWhatsapp");

    const ctaSectionKey = "booking";

    cta.href = buildUrl("booking", ctaSectionKey);



    if (window.DEMO_MODE) {

      cta.onclick = (e) => {

        e.preventDefault();

        scrollToSection(ctaSectionKey);

        openBookingModal();

      };

    }

  }

}



/* UI Logic */

function renderUITexts() {

  const lblHotel = document.getElementById("lblHotel");

  if (lblHotel) lblHotel.textContent = t("ui.selectHotel");



  const selectedHotel = getSelectedHotel();

  const ctx = document.getElementById("contextLine");



  if (ctx) {
    if (!selectedHotel) ctx.textContent = "Santis Club";
    else {
      const name = selectedHotel.translations?.tr?.name || state.hotel;
      ctx.textContent = name;
    }
  }



  const heroTitle = document.getElementById("heroTitle");

  if (heroTitle) heroTitle.textContent = t("hero.title");



  const heroSubtitleEl = document.getElementById("heroSubtitle");
  if (heroSubtitleEl) {
    if (selectedHotel) {
      heroSubtitleEl.textContent = selectedHotel.translations?.tr?.description || "";
    } else {
      const subtitleTpl = t("hero.subtitle");
      const locDefault = t("hero.locationDefault");
      heroSubtitleEl.textContent = subtitleTpl.replace("{location}", locDefault);
    }
  }



  const topPicksTitle = document.getElementById("topPicksTitle");

  if (topPicksTitle) topPicksTitle.textContent = t("sections.topPicks");



  const catTitle = selectedHotel ? t("sections.categoriesHotel") : "Santis Spa Koleksiyonu";

  const categoriesTitle = document.getElementById("categoriesTitle");

  if (categoriesTitle) categoriesTitle.textContent = catTitle;



  const catSub = selectedHotel ? t("sections.categoryCardSubtitleHotel") : "Tüm şubelerimizde geçerli spa ritüelleri";

  const catPill = document.getElementById("categoriesContextPill");

  const catSubtitle = document.getElementById("categoriesSubtitle");



  const copyBtn2 = document.getElementById("svcCopyLink");

  if (copyBtn2) copyBtn2.title = t("ui.copied");



  if (catPill) catPill.textContent = selectedHotel ? (selectedHotel.translations?.tr?.name || selectedHotel.slug) : "Santis Club";

  if (catSubtitle) catSubtitle.textContent = catSub;



  const partnerTitle = document.getElementById("partnerTitle");

  if (partnerTitle) partnerTitle.textContent = "Hizmet Noktalarımız";

  const aboutTitle = document.getElementById("aboutTitle");

  if (aboutTitle) aboutTitle.textContent = t("nav.about");

  const teamTitle = document.getElementById("teamTitle");

  if (teamTitle) teamTitle.textContent = t("nav.team");



  const svcSearch = document.getElementById("serviceSearch");

  if (svcSearch) svcSearch.placeholder = t("ui.serviceSearchPlaceholder");



  const chipToday = document.getElementById("chipToday");

  if (chipToday) chipToday.textContent = t("ui.onlyToday");

  const chipDurAll = document.getElementById("chipDurAll");

  if (chipDurAll) chipDurAll.textContent = t("ui.durAll");

  const chipDur30 = document.getElementById("chipDur30");

  if (chipDur30) chipDur30.textContent = t("ui.dur30");

  const chipDur60 = document.getElementById("chipDur60");

  if (chipDur60) chipDur60.textContent = t("ui.dur60");

  const lblSort = document.getElementById("lblSort");

  if (lblSort) lblSort.textContent = t("ui.sortLabel");

  const svcFiltersClear = document.getElementById("serviceFiltersClear");

  if (svcFiltersClear) svcFiltersClear.textContent = t("ui.clearFilters");



  const sortSel = document.getElementById("serviceSort");

  if (sortSel) {

    for (const opt of sortSel.options) {

      const label = t("ui.sort." + opt.value);

      if (label) opt.textContent = label;

    }

  }

}



function renderHotelSelect() {

  const sel = document.getElementById("hotelSelect");

  if (!sel) return;

  sel.innerHTML = "";

  const optAll = document.createElement("option");

  optAll.value = "";

  optAll.textContent = "Santis Club (Tüm Şubeler)";

  sel.appendChild(optAll);



  for (const h of getHotels()) {
    const opt = document.createElement("option");
    opt.value = h.slug;
    opt.textContent = h.translations?.tr?.name || h.slug;
    sel.appendChild(opt);
  }

  sel.value = state.hotel;

}



/* Category & Top Picks Logic */

function renderTopPicks() {
  const container = document.getElementById("topPicks");
  if (!container) return;
}

function renderCategoryToolbar() {

  const bar = document.getElementById("categoryToolbar");

  if (!bar) return;

  const selectedHotel = getSelectedHotel?.() || null;

  if (!selectedHotel) {

    bar.style.display = "none";

    state.categoryView = "all";

    updateTopPicksPopoverContent();

    return;

  }

  bar.style.display = "flex";

  bar.innerHTML = "";



  const btnAll = document.createElement("button");

  btnAll.className = "chipbtn" + (state.categoryView === "all" ? " active" : "");

  btnAll.textContent = t("ui.filterAll");

  btnAll.onclick = () => {

    state.categoryView = "all";

    renderCategoryToolbar();

    renderCategories();

  };



  const btnTop = document.createElement("button");

  btnTop.className = "chipbtn" + (state.categoryView === "top" ? " active" : "");

  btnTop.textContent = t("ui.filterTopPicks");

  btnTop.onclick = () => {

    state.categoryView = "top";

    renderCategoryToolbar();

    renderCategories();

  };



  bar.appendChild(btnAll);

  bar.appendChild(btnTop);

  updateTopPicksPopoverContent();

}



function updateTopPicksPopoverContent() {

  const hintWrap = document.getElementById("topPicksHint");

  const hintText = document.getElementById("topPicksHintText");

  const selectedHotel = getSelectedHotel();

  const show = !!selectedHotel && state.categoryView === "top";



  if (hintWrap) hintWrap.style.display = show ? "block" : "none";

  if (show && hintText) hintText.textContent = t("ui.topPicksHint");

}



function renderCategories() {

  const grid = document.getElementById("categoriesGrid");

  if (!grid) return;

  grid.innerHTML = "";



  const selectedHotel = getSelectedHotel();

  const hotelSlug = selectedHotel?.slug || "";

  const categories = CONTENT?.global?.categories || [];



  const topPickSet = new Set();

  if (selectedHotel && Array.isArray(selectedHotel.featuredServices)) {

    const services = CONTENT?.global?.services || {};

    selectedHotel.featuredServices.forEach(sid => {

      if (services[sid]?.categoryId) topPickSet.add(services[sid].categoryId);

    });

  }



  for (const cat of categories) {

    if (state.categoryView === "top" && selectedHotel) {

      if (!topPickSet.has(cat.id)) continue;

    }



    const count = countServicesByCategory(cat.id, hotelSlug);

    const card = document.createElement("div");

    card.className = "cat-card card " + (state.activeCategoryId === cat.id ? "active" : "");



    card.innerHTML = `

      <div class="card-body" style="padding:16px;">

         ${count > 0 ? `<div class="count-badge">${count}</div>` : ""}

         <div class="card-title" style="margin-bottom:6px;">${t(cat.navKey)}</div>

         <div class="card-desc">${t(cat.descriptionKey)}</div>

      </div>

    `;



    card.onclick = () => {
      state.activeCategoryId = cat.id;
      renderCategories();
      renderServiceResults();
    };

    grid.appendChild(card);

  }

}



function countServicesByCategory(categoryId, hotelSlug) {

  const services = CONTENT?.global?.services || {};

  let n = 0;

  for (const svc of Object.values(services)) {

    if (!svc || svc.categoryId !== categoryId) continue;

    if (hotelSlug && Array.isArray(svc.hotelSlugs) && svc.hotelSlugs.length > 0 && !svc.hotelSlugs.includes(hotelSlug)) continue;

    n++;

  }

  return n;

}





function renderServiceResults() {

  const listEl = document.getElementById("serviceResultsList");

  const emptyEl = document.getElementById("serviceResultsEmpty");

  const countEl = document.getElementById("countText");

  const metaEl = document.getElementById("serviceResultsMeta");



  if (!listEl) return;

  listEl.innerHTML = "";

  if (emptyEl) emptyEl.style.display = "none";



  const selectedHotel = getSelectedHotel();

  const hotelSlug = selectedHotel?.slug || "";

  const categoryId = state.activeCategoryId;

  const categories = CONTENT?.global?.categories || [];

  const catObj = categories.find(c => c.id === categoryId);



  if (metaEl) metaEl.textContent = catObj ? t(catObj.navKey) : t("ui.pickCategory");



  if (!catObj) {

    if (emptyEl) {

      emptyEl.style.display = "block";

      emptyEl.textContent = t("ui.pickCategory");

    }

    return;

  }



  let services = [];

  const allServices = CONTENT?.global?.services || {};



  for (const [id, svc] of Object.entries(allServices)) {

    if (svc.categoryId !== categoryId) continue;

    if (hotelSlug && Array.isArray(svc.hotelSlugs) && !svc.hotelSlugs.includes(hotelSlug)) continue;

    services.push({ id, ...svc });

  }



  if (countEl) countEl.textContent = services.length;



  for (const svc of services) {

    // 3. Render Card
    // 3. Render Card
    const serviceCard = document.createElement("div");
    serviceCard.className = "svc-card lux-card-surface";
    const name = trText(svc.name);
    const desc = trText(svc.desc);

    // Ensure slug
    const targetSlug = ensureSlug(svc);

    serviceCard.innerHTML = `
      <div class="svc-card-content">
        <div class="svc-card-title">${name}</div>
        <div class="svc-card-desc" style="color:var(--text-muted); font-size:14px; margin-bottom:10px;">
           ${desc}
        </div>
        <div class="svc-card-meta">
          <span>⏱ ${svc.duration} dk</span>
          ${svc.price ? `<span>• ${svc.price}€</span>` : ""}
        </div>
      </div>
      <div class="svc-card-action">
         <button class="btn-sm" type="button" data-book>Rezervasyon</button>
      </div>
    `;

    // Event
    const btn = serviceCard.querySelector("[data-book]");
    if (btn) btn.onclick = (e) => {
      e.stopPropagation();
      state.selectedServiceId = svc.id;
      openBookingModal();
      // Optional: Redirect if needed, or just open modal
      // window.location.href = `service-detail.html?slug=${encodeURIComponent(targetSlug)}`;
    };

    // Append
    if (listEl) listEl.appendChild(serviceCard); // Use listEl instead of grid which was undefined in this scope if copied from rendering logic elsewhere

  }

}



/* Booking Logic (Full) */

function openBookingModal() {

  const modal = document.getElementById("bookingModal");

  modal.classList.add("open");

  modal.setAttribute("aria-hidden", "false");



  hideAlert("bookingAlert");

  hideAlert("formAlert");

  document.getElementById("successBox").classList.remove("show");

  document.getElementById("successBox").textContent = "";

  document.getElementById("shareWhatsappBtn").style.display = "none";



  renderBookingUI();

  updateWhatsappPreview();



  setTimeout(() => document.getElementById("bookHotel")?.focus(), 50);

  window.addEventListener("keydown", escCloseOnce);

}



function closeBookingModal() {

  const modal = document.getElementById("bookingModal");

  modal.classList.remove("open");

  modal.setAttribute("aria-hidden", "true");

  window.removeEventListener("keydown", escCloseOnce);

}



function escCloseOnce(e) {

  if (e.key === "Escape") closeBookingModal();

}



function renderBookingUI() {

  // Titles

  document.getElementById("bookingModalTitle").textContent = t("booking.title");

  const selectedHotel = getSelectedHotel();

  const hotelName = selectedHotel ? (selectedHotel.translations?.[state.lang]?.name || selectedHotel.translations?.tr?.name) : "Santis Club";

  document.getElementById("bookingModalSub").textContent = hotelName;



  document.getElementById("waPanelTitle").textContent = t("booking.buttons.whatsapp"); // Using button text as title for now or add specific title key

  document.getElementById("formPanelTitle").textContent = t("booking.title");



  // Labels

  const labels = {

    lblBookHotel: "booking.fields.hotel",

    lblBookService: "booking.fields.service",

    lblBookDate: "booking.fields.date",

    lblBookTime: "booking.fields.time",

    lblBookPeople: "booking.fields.guests",

    lblBookRoom: "booking.fields.room",

    lblBookNotes: "booking.fields.notes",

    lblFullName: "booking.fields.name",

    lblPhone: "booking.fields.phone",

    lblFormNotes: "booking.fields.notes"

  };

  for (const [id, key] of Object.entries(labels)) {

    const el = document.getElementById(id);

    if (el) el.textContent = t(key);

  }



  document.getElementById("txtConsentPrivacy").textContent = t("booking.fields.agree_privacy");

  document.getElementById("txtConsentTerms").textContent = t("booking.fields.agree_cancel");



  // Buttons

  document.getElementById("whatsappBtn").textContent = t("booking.buttons.whatsapp");

  document.getElementById("submitFormBtn").textContent = t("booking.buttons.submit");

  // document.getElementById("shareWhatsappBtn").textContent = t("booking.success.shareWhatsapp"); // Removed in new structure, handle if needed



  // Hotel Select

  const bookHotel = document.getElementById("bookHotel");

  bookHotel.innerHTML = "";

  const opt0 = document.createElement("option");

  opt0.value = "";

  opt0.textContent = "—";

  bookHotel.appendChild(opt0);



  for (const h of getHotels()) {

    const opt = document.createElement("option");

    opt.value = h.slug;

    opt.textContent = h.translations?.[state.lang]?.name || h.translations?.tr?.name || h.slug;

    bookHotel.appendChild(opt);

  }

  bookHotel.value = state.hotel || "";



  bookHotel.onchange = () => {

    renderServiceSelectInModal();

    updateWhatsappPreview();

  };



  renderServiceSelectInModal();

  updateWhatsappPreview();



  // Wire inputs

  const watchIds = ["bookDate", "bookTime", "bookPeople", "bookRoom", "bookNotes"];

  watchIds.forEach(id => {

    document.getElementById(id).addEventListener("input", updateWhatsappPreview);

  });



  document.getElementById("copyMsgBtn").onclick = async () => {

    try {

      await navigator.clipboard.writeText(document.getElementById("waPreview").value || "");

      alert(t("ui.copied") || "Copied");

    } catch (e) { console.error(e); }

  };



  document.getElementById("submitFormBtn").onclick = submitOnlineForm;

}



function renderServiceSelectInModal() {

  const bookService = document.getElementById("bookService");

  const bookHotel = document.getElementById("bookHotel");

  const hotelSlug = bookHotel.value;

  const hotelObj = getHotels().find(h => h.slug === hotelSlug);



  bookService.innerHTML = "";

  if (!hotelSlug) {

    bookService.disabled = true;

    const opt = document.createElement("option");

    opt.textContent = "—"; // Simplified fallback

    bookService.appendChild(opt);

    return;

  }

  bookService.disabled = false;



  const opt0 = document.createElement("option");

  opt0.value = "";

  opt0.textContent = "—";

  bookService.appendChild(opt0);



  const services = CONTENT?.global?.services || {};

  const featured = hotelObj?.featuredServices || [];



  // Featured Group

  if (featured.length) {

    const g1 = document.createElement("optgroup");

    g1.label = t("sections.topPicks") || "Top Picks"; // Reusing existing key

    featured.forEach(sid => {

      if (services[sid]) {

        const opt = document.createElement("option");

        opt.value = sid;

        opt.textContent = services[sid].name?.[state.lang] || services[sid].name?.tr;

        g1.appendChild(opt);

      }

    });

    bookService.appendChild(g1);

  }



  // All Group

  const g2 = document.createElement("optgroup");

  g2.label = t("booking.serviceGroups.otherServices") || "Others";

  g2.label = "Others"; // Fallback

  Object.keys(services).forEach(sid => {

    if (!featured.includes(sid)) {

      const opt = document.createElement("option");

      opt.value = sid;

      opt.textContent = services[sid].name?.[state.lang] || services[sid].name?.tr;

      g2.appendChild(opt);

    }

  });

  bookService.appendChild(g2);



  if (state.selectedServiceId) bookService.value = state.selectedServiceId;

  bookService.onchange = updateWhatsappPreview;

}



function getBookingVars() {

  const hotelSlug = document.getElementById("bookHotel").value;

  const serviceId = document.getElementById("bookService").value;

  const hotelObj = getHotels().find(h => h.slug === hotelSlug);

  const hotelName = hotelObj ? (hotelObj.translations?.[state.lang]?.name || hotelObj.translations?.tr?.name) : "";

  const serviceObj = (CONTENT?.global?.services || {})[serviceId];

  const serviceName = serviceObj ? (serviceObj.name?.[state.lang] || serviceObj.name?.tr) : "";



  return {

    hotelSlug,

    serviceId,

    hotelName,

    serviceName,

    date: document.getElementById("bookDate").value || "",

    time: document.getElementById("bookTime").value || "",

    people: document.getElementById("bookPeople").value || "",

    room: document.getElementById("bookRoom").value || "",

    notes: document.getElementById("bookNotes").value || ""

  };

}



function updateWhatsappPreview() {

  hideAlert("bookingAlert");

  const vars = getBookingVars();

  const btn = document.getElementById("whatsappBtn");



  if (!vars.hotelSlug || !vars.serviceId) {

    if (btn) {

      btn.classList.add("disabled");

      btn.href = "#";

    }

    return;

  }

  if (btn) btn.classList.remove("disabled");



  const msg = buildWhatsappMessage(vars);

  const waNumber = "905348350169"; // Simplified default

  const waLink = `https://wa.me/${waNumber}?text=${encodeURIComponent(msg)}`;

  if (btn) btn.href = waLink;



  const pv = document.getElementById("waPreview");

  if (pv) pv.value = msg;

}



function buildWhatsappMessage(vars) {

  const tpl = t("booking.whatsapp_template");

  let priceTimeLine = "";

  // Simplified price logic for brevity, assuming standard EUR/min

  const msg = tpl

    .replace("{hotel}", vars.hotelName)

    .replace("{service}", vars.serviceName)

    .replace("{date}", vars.date)

    .replace("{time}", vars.time)

    .replace("{guests}", vars.people) // Changed from people to guests to match template

    .replace("{kisi}", vars.people) // Turkish template uses kisi

    .replace("{name}", vars.hotelName) // Note: Template uses name for user name usually, check logic. 

    // Actually template uses {name} for user name. We need user name input in getBookingVars if we want to use it in WA message.

    // For now, let's just replace what we have.

    .replace("{url}", window.location.href);



  return cleanWhatsappMessage(msg);

}



function cleanWhatsappMessage(msg) {

  return msg.split("\n").filter(line => {

    const t = line.trim();

    if (!t) return false;

    if (t.includes("{notes}") || t.includes("{priceTime}")) return false;

    return true;

  }).join("\n");

}



function submitOnlineForm() {

  // Demo submission

  const vars = getBookingVars();

  if (!vars.hotelSlug || !vars.serviceId) {

    showAlert("formAlert", "Hotel/Service required");

    return;

  }

  const ref = "SC-" + Math.floor(Math.random() * 900000);

  const box = document.getElementById("successBox");

  box.textContent = `Booking Received! Ref: ${ref}`; // Simplified fallback

  box.classList.add("show");

}



function showAlert(id, msg) {

  const el = document.getElementById(id);

  if (el) { el.textContent = msg; el.classList.add("show"); }

}

function hideAlert(id) {

  const el = document.getElementById(id);

  if (el) { el.textContent = ""; el.classList.remove("show"); }

}



/* Service Drawer */

function openServiceDrawer(id) {

  state.selectedServiceId = id;

  state.svcOpen = true;

  const drawer = document.getElementById("svcDrawer");

  const overlay = document.getElementById("svcOverlay");

  if (drawer) drawer.classList.add("open");

  if (overlay) overlay.style.display = "block";



  const svc = CONTENT?.global?.services?.[id];

  if (svc) {
    document.getElementById("svcDrawerTitle").textContent = trText(svc.name);
    document.getElementById("svcDrawerDesc").textContent = trText(svc.desc);

    const bookBtn = document.getElementById("svcDrawerBook");
    if (bookBtn) bookBtn.onclick = () => {
      state.selectedServiceId = id;
      openBookingModal();
    };
  }

}



function closeServiceDrawer() {

  state.svcOpen = false;

  const drawer = document.getElementById("svcDrawer");

  const overlay = document.getElementById("svcOverlay");

  if (drawer) drawer.classList.remove("open");

  if (overlay) overlay.style.display = "none";

}



/* Init */

function renderAll() {

  document.documentElement.lang = state.lang;



  renderHotelSelect();

  renderNav();

  renderUITexts();

  if (typeof renderTopPicks === "function") {
    renderTopPicks();
  } else {
    console.warn("[renderAll] renderTopPicks yok, atlanıyor");
  }

  renderCategoryToolbar();

  renderCategories();

  renderServiceResults();

  localStorage.setItem("santis_hotel", state.hotel);

}



function renderHomeSections() {

  const mapping = {

    "hammam": "grid-hammam",

    "classicMassages": "grid-massages",

    "extraEffective": "grid-extra",

    "faceSothys": "grid-skincare",
    "skincare": "grid-skincare"

  };



  Object.entries(mapping).forEach(([catKey, gridId]) => {

    const grid = document.getElementById(gridId);

    if (!grid) return;

    grid.innerHTML = "";



    let services = null;

    if (CONTENT.global[catKey] && Array.isArray(CONTENT.global[catKey])) {

      services = CONTENT.global[catKey];

    } else {

      // Fallback check

      services = Object.entries(CONTENT.global.services || {}).map(([id, s]) => ({ id, ...s })).filter(s => s.categoryId === catKey);

    }



    if (!services || services.length === 0) return;



    // Take top 4

    const show = services.slice(0, 4);



    show.forEach((svc, index) => {

      const card = document.createElement("div");

      // Add reveal-on-scroll

      card.className = "card reveal-on-scroll stagger-" + ((index % 3) + 1);



      const name = trText(svc.name) || svc.id;
      const desc = trText(svc.desc);

      const dur = svc.duration || 50;



      card.innerHTML = `

            <div class="card-img-wrap lux-card-surface">

            </div>

            <div class="card-content">

               <div class="card-title clamp-2">${name}</div>

               <div class="card-desc clamp-2" style="font-size:14px; color:var(--text-muted); margin-bottom:12px;">${desc}</div>

               <div class="card-footer">

                  <span>⏱ ${dur} dk</span>

                  <span class="card-cta">İncele &rarr;</span>

               </div>

            </div>

          `;



      card.onclick = () => {

        // Navigate to service detail (guard missing slug/id)
        const targetSlug = svc.slug || svc.id;
        if (!targetSlug) {
          console.warn("Service slug/id missing for card", svc);
          return;
        }
        window.location.href = `service-detail.html?slug=${encodeURIComponent(targetSlug)}`;

      };



      grid.appendChild(card);

    });

  });

}



const FALLBACK_DATA = {

  "global": {

    "navModel": [
      { "key": "hammam", "route": "hammam", "label": "Hamam" },
      { "key": "massages", "route": "massages", "label": "Masajlar" },
      { "key": "skincare", "route": "skincare", "label": "Cilt Bakımı" },
      { "key": "gallery", "route": "gallery", "label": "Galeri" }
    ],

    "categories": [

      { "id": "hammam", "navKey": "nav.hammam", "descriptionKey": "desc.hammam" },

      { "id": "classicMassages", "navKey": "nav.classicMassages", "descriptionKey": "desc.classicMassages" },

      { "id": "sportsTherapy", "navKey": "nav.sportsTherapy", "descriptionKey": "desc.sportsTherapy" },

      { "id": "asianMassages", "navKey": "nav.asianMassages", "descriptionKey": "desc.asianMassages" },

      { "id": "ayurveda", "navKey": "nav.ayurveda", "descriptionKey": "desc.ayurveda" },

      { "id": "signatureCouples", "navKey": "nav.signatureCouples", "descriptionKey": "desc.signatureCouples" },

      { "id": "kidsFamily", "navKey": "nav.kidsFamily", "descriptionKey": "desc.kidsFamily" },

      { "id": "faceSothys", "navKey": "nav.faceSothys", "descriptionKey": "desc.faceSothys" }

    ]

  }

};



async function loadContent() {

  try {

    // If opened directly via file://, CORS will block the fetch; rely on fallback.

    if (location.protocol === "file:") {

      console.warn("⚠️ Dosya sistemi (file://) algılandı. Tarayıcı güvenliği (CORS) nedeniyle dış JSON dosyası yüklenemiyor.\n👉 Site çalışmaya devam etmesi için 'FALLBACK_DATA' (Demo Verisi) kullanılıyor.\n💡 Çözüm: Tam deneyim için VS Code  gibi bir yerel sunucu kullanın.");

      return FALLBACK_DATA;

    }



    const res = await fetch("data/site_content.json");

    // If fetch fails, jump to catch

    if (!res.ok) throw new Error("JSON Fetch Failed");



    const data = await res.json();

    const base = data.global ? data : { global: data };



    // FILL MISSING DATA IF NOT PRESENT IN JSON

    if (!base.global.navModel) base.global.navModel = FALLBACK_DATA.global.navModel;

    if (!base.global.categories) base.global.categories = FALLBACK_DATA.global.categories;



    // Standardize Services (Flatten arrays to object)

    if (!base.global.services) {

      base.global.services = {};

      const keys = ["hammam", "classicMassages", "extraEffective", "faceSothys", "asianMassages", "sportsTherapy", "ayurveda", "signatureCouples", "kidsFamily"];



      keys.forEach(key => {

        if (Array.isArray(base.global[key])) {

          base.global[key].forEach(svc => {

            if (svc.id) {

              ensureSlug(svc);

              svc.categoryId = key;

              base.global.services[svc.id] = svc;

            }

          });

        }

      });

    }



    return base;

  } catch (e) {

    console.warn("Using Fallback Data:", e);

    return FALLBACK_DATA;

  }

}



/* Cinematic Intro Logic */

function initCinematicIntro() {

  const preloader = document.getElementById("preloader");

  if (!preloader) return;



  // Ensure animations are prepared

  const heroTitle = document.getElementById("heroTitle");

  const heroSub = document.getElementById("heroSubtitle");



  if (heroTitle) {

    heroTitle.style.opacity = "0";

    heroTitle.style.transform = "translateY(30px)";

  }

  if (heroSub) {

    heroSub.style.opacity = "0";

    heroSub.style.transform = "translateY(30px)";

  }



  // Minimum wait time for the logo pulse to be appreciated

  const minTime = 1500;



  setTimeout(() => {

    preloader.classList.add("hidden");



    // Trigger Hero Animations after preloader is lifting

    setTimeout(() => {

      if (heroTitle) {

        heroTitle.style.transition = "opacity 1.2s ease-out, transform 1.2s cubic-bezier(0.2, 0.8, 0.2, 1)";

        heroTitle.style.opacity = "1";

        heroTitle.style.transform = "translateY(0)";

      }



      if (heroSub) {

        heroSub.style.transition = "opacity 1.2s ease-out 0.2s, transform 1.2s cubic-bezier(0.2, 0.8, 0.2, 1) 0.2s";

        heroSub.style.opacity = "1";

        heroSub.style.transform = "translateY(0)";

      }

    }, 400);



  }, minTime);

}



function initScrollObserver() {

  const observer = new IntersectionObserver((entries) => {

    entries.forEach(entry => {

      if (entry.isIntersecting) {

        entry.target.classList.add('is-visible');

        observer.unobserve(entry.target);

      }

    });

  }, { threshold: 0.1 });



  document.querySelectorAll('.reveal-on-scroll').forEach(el => observer.observe(el));

}



async function init() {

  const params = new URLSearchParams(window.location.search);



  // 1. Language & Hotel from URL
  state.lang = "tr";



  if (params.has("hotel")) {

    state.hotel = params.get("hotel");

    localStorage.setItem("santis_hotel", state.hotel);

  } else {

    state.hotel = localStorage.getItem("santis_hotel") || "";

  }



  CONTENT = await loadContent();

  if (!CONTENT) return;



  // Wire global events

  document.getElementById("svcOverlay")?.addEventListener("click", closeServiceDrawer);

  document.getElementById("svcDrawerClose")?.addEventListener("click", closeServiceDrawer);

  document.getElementById("closeBookingBtn2")?.addEventListener("click", closeBookingModal);

  document.getElementById("bookingCloseBtn")?.addEventListener("click", closeBookingModal);



  // 2. Handle Routing State (View/Section)

  const view = params.get("view");

  const section = params.get("section");



  if (view) {

    setActiveCategoryFromRoute(view);

  }



  renderAll();

  renderHomeSections();



  // Cinematic Intro & Scroll

  initCinematicIntro();



  // Initialize scroll observer AFTER content is rendered

  setTimeout(() => initScrollObserver(), 100);



  // 3. Post-Render Actions

  if (section === "booking") {

    scrollToSection("booking");

    openBookingModal();

  } else if (view) {

    // If view matches a specific section ID, scroll there. Otherwise go to results.

    const target = document.getElementById(view) || document.querySelector(`[data-section="${view}"]`);

    if (target) scrollToSection(view);

    else if (state.activeCategoryId) scrollToSection("service-results");

  }



  // 4. Favicon Fix (Prevent 404)

  if (!document.querySelector("link[rel*='icon']")) {

    const link = document.createElement('link');

    link.rel = 'shortcut icon';

    link.href = 'favicon.ico';

    document.head.appendChild(link);

  }

}



// Start the app

init();


/* Sticky Header Patch */
document.addEventListener('DOMContentLoaded', () => {
  const h = document.getElementById('nv-header');
  if (h) {
    const onScroll = () => h.classList.toggle('shrink', window.scrollY > 50);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }
});

/* Safe Preloader Remover */
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    const p = document.getElementById('preloader');
    if (p) p.classList.add('hidden');
  }, 500);
});

/* SANTIS FINAL POLISH ENGINE */
document.addEventListener('DOMContentLoaded', () => {
  // 1. Erişilebilirlik: İkon butonlarını isimlendir
  document.querySelectorAll('.icon-btn').forEach(btn => {
    if (!btn.getAttribute('aria-label')) btn.setAttribute('aria-label', 'Santis Action');
  });

  // 2. SEO & Güvenlik: Harici linkleri zırhla
  document.querySelectorAll('a[href^="http"]').forEach(link => {
    link.setAttribute('rel', 'noopener noreferrer');
  });

  // 3. Performans: Görsellere Layout Shift koruması ekle
  document.querySelectorAll('img').forEach(img => {
    if (!img.getAttribute('width')) img.setAttribute('width', '600');
    if (!img.getAttribute('height')) img.setAttribute('height', '400');
  });

  console.log("🏆 Santis Club: 10/10 Mükemmellik Mührü Uygulandı.");
});

/* SANTIS PATH RESOLVER — 0 HATA GARANTİSİ */
window.SANTIS_RESOLVE_PATH = function (slug) {
  const isLocal = window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1";
  // Antigravity veya Canlı Sunucu fark etmeksizin yolu bulur
  const root = isLocal ? '/' : window.location.pathname.split('/')[1] === 'tr' ? '/' : '/';

  return `${root}service-detail.html?slug=${slug}`;
};

/* DATA GUARD — EKSİK VERİDE SİTEYİ AYAKTA TUTAR */
window.getSantisData = function () {
  try {
    const hammam = window.NV_HAMMAM || [];
    const massage = window.NV_MASSAGES || [];
    const skin = window.NV_SKINCARE || [];

    const all = [...hammam, ...massage, ...skin];
    if (all.length === 0) console.warn("Santis Warning: Data sets are empty.");
    return all;
  } catch (e) {
    console.error("Santis Critical Error: Data Bridge Failed.", e);
    return [];
  }
};

/* 0 HATA GÖRSEL YÖNETİMİ */
document.addEventListener('error', function (e) {
  if (e.target.tagName.toLowerCase() === 'img') {
    // Prevent infinite loops if placeholder is also missing
    if (e.target.src.includes('luxury-placeholder.webp')) return;

    console.log("Görsel kurtarılıyor: " + e.target.src);
    e.target.src = "assets/img/luxury-placeholder.webp"; // Veya şık bir logo
    e.target.style.filter = "grayscale(1) opacity(0.5)";
  }
}, true);

