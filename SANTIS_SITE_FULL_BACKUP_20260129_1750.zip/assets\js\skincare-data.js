// assets/js/skincare-data.js
// SANTIS — Skincare dataset (19 items)
// Features: Absolute Paths, Fallback Guard, Zero 404s

(function () {
    const DETAIL_BASE = "../../service-detail.html?slug=";

    // ROOT PATH FIX & PLACEHOLDER MAPPING
    // Since actual images are missing, we map to the known existing placeholder
    const IMG = {
        base: "/assets/img/cards/hamam.webp",
        cleanse: "/assets/img/cards/hamam.webp",
        glow: "/assets/img/cards/hamam.webp",
        hydrate: "/assets/img/cards/hamam.webp",
        calm: "/assets/img/cards/hamam.webp",
        luxe: "/assets/img/cards/hamam.webp",
    };

    // Price is intentionally placeholder (0). UI shows "Fiyat sorunuz" when price === 0.
    window.NV_SKINCARE = [
        // CLASSIC FACIALS
        {
            id: "classic-facial",
            title: "Klasik Cilt Bakımı",
            duration: "60 dk",
            tier: "CLASSIC",
            price: 0,
            desc: "Temizleme + tonik + maske — cildi dengeler, canlılık verir.",
            img: IMG.base,
            category: "classicFacials",
            href: DETAIL_BASE + "classic-facial#classicFacials",
            cart: { id: "skincare_classic", name: "Klasik Cilt Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "deep-cleanse",
            title: "Derin Temizleme Bakımı",
            duration: "70 dk",
            tier: "CLEAN",
            price: 0,
            desc: "Gözenek odaklı arındırma — siyah nokta ve sebum dengesine destek.",
            img: IMG.cleanse,
            category: "classicFacials",
            href: DETAIL_BASE + "deep-cleanse#classicFacials",
            cart: { id: "skincare_deepcleanse", name: "Derin Temizleme Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "enzyme-peel",
            title: "Enzim Peeling Bakımı",
            duration: "45 dk",
            tier: "PEEL",
            price: 0,
            desc: "Nazik yenileme — pürüzsüz görünüm ve ışıltı için couture dokunuş.",
            img: IMG.glow,
            category: "classicFacials",
            href: DETAIL_BASE + "enzyme-peel#classicFacials",
            cart: { id: "skincare_enzyme", name: "Enzim Peeling Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "detox-charcoal",
            title: "Detox Kömür Maske",
            duration: "40 dk",
            tier: "DETOX",
            price: 0,
            desc: "Şehir yorgunluğuna karşı arındırma — matlığı azaltmaya destek.",
            img: IMG.cleanse,
            category: "classicFacials",
            href: DETAIL_BASE + "detox-charcoal#classicFacials",
            cart: { id: "skincare_detox", name: "Detox Kömür Maske", price: 0, cat: "skincare" },
        },
        // HYDRATION & GLOW
        {
            id: "hyaluron-hydrate",
            title: "Hyaluron Nem Terapisi",
            duration: "60 dk",
            tier: "HYDRATE",
            price: 0,
            desc: "Yoğun nem + dolgun görünüm — bariyeri destekler, cildi yumuşatır.",
            img: IMG.hydrate,
            category: "hydrationGlow",
            href: DETAIL_BASE + "hyaluron-hydrate#hydrationGlow",
            cart: { id: "skincare_hyaluron", name: "Hyaluron Nem Terapisi", price: 0, cat: "skincare" },
        },
        {
            id: "vitamin-c-glow",
            title: "Vitamin C Glow",
            duration: "50 dk",
            tier: "GLOW",
            price: 0,
            desc: "Aydınlık ve taze görünüm — ışıltıyı artıran premium protokol.",
            img: IMG.glow,
            category: "hydrationGlow",
            href: DETAIL_BASE + "vitamin-c-glow#hydrationGlow",
            cart: { id: "skincare_vitc", name: "Vitamin C Glow", price: 0, cat: "skincare" },
        },
        {
            id: "oxygen-boost",
            title: "Oksijen Boost Bakımı",
            duration: "45 dk",
            tier: "OXYGEN",
            price: 0,
            desc: "Canlandırıcı etki — daha dinlenmiş ve parlak bir görünüm.",
            img: IMG.base,
            category: "hydrationGlow",
            href: DETAIL_BASE + "oxygen-boost#hydrationGlow",
            cart: { id: "skincare_oxygen", name: "Oksijen Boost Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "glass-skin",
            title: "Glass Skin Ritüeli",
            duration: "75 dk",
            tier: "LUXE",
            price: 0,
            desc: "Katmanlı nem + maske — cam gibi parlak, pürüzsüz bir bitiş.",
            img: IMG.luxe,
            category: "hydrationGlow",
            href: DETAIL_BASE + "glass-skin#hydrationGlow",
            cart: { id: "skincare_glass", name: "Glass Skin Ritüeli", price: 0, cat: "skincare" },
        },
        // ANTI-AGING & LIFT
        {
            id: "collagen-lift",
            title: "Kolajen Lifting Bakımı",
            duration: "70 dk",
            tier: "LIFT",
            price: 0,
            desc: "Sıkılık hissi ve toparlanma — yorgun görünümü azaltmaya destek.",
            img: IMG.luxe,
            category: "antiAgingLift",
            href: DETAIL_BASE + "collagen-lift#antiAgingLift",
            cart: { id: "skincare_collagen", name: "Kolajen Lifting Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "anti-aging-pro",
            title: "Anti-Aging Pro Bakım",
            duration: "80 dk",
            tier: "PRO",
            price: 0,
            desc: "İnce çizgi görünümü hedefleyen kapsamlı protokol — couture bakım.",
            img: IMG.base,
            category: "antiAgingLift",
            href: DETAIL_BASE + "anti-aging-pro#antiAgingLift",
            cart: { id: "skincare_antiaging", name: "Anti-Aging Pro Bakım", price: 0, cat: "skincare" },
        },
        {
            id: "led-rejuvenation",
            title: "LED Rejuvenation",
            duration: "40 dk",
            tier: "LED",
            price: 0,
            desc: "Işık desteğiyle bakım rutini — cilt görünümünü dengelemeye yardımcı.",
            img: IMG.calm,
            category: "antiAgingLift",
            href: DETAIL_BASE + "led-rejuvenation#antiAgingLift",
            cart: { id: "skincare_led", name: "LED Rejuvenation", price: 0, cat: "skincare" },
        },
        // SPOT / ACNE / SENSITIVE
        {
            id: "brightening-spot",
            title: "Leke Karşıtı Aydınlatıcı Bakım",
            duration: "60 dk",
            tier: "BRIGHT",
            price: 0,
            desc: "Ton eşitleme odaklı — daha homojen bir görünüm için destek.",
            img: IMG.glow,
            category: "targetedCare",
            href: DETAIL_BASE + "brightening-spot#targetedCare",
            cart: { id: "skincare_bright", name: "Leke Karşıtı Aydınlatıcı Bakım", price: 0, cat: "skincare" },
        },
        {
            id: "acne-balance",
            title: "Akne & Sebum Denge Bakımı",
            duration: "60 dk",
            tier: "ACNE",
            price: 0,
            desc: "Arındırma + dengeleme — yağlı/karma ciltler için hedefli bakım.",
            img: IMG.cleanse,
            category: "targetedCare",
            href: DETAIL_BASE + "acne-balance#targetedCare",
            cart: { id: "skincare_acne", name: "Akne & Sebum Denge Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "sensitive-soothe",
            title: "Hassas Cilt Sakinleştirici Bakım",
            duration: "50 dk",
            tier: "CALM",
            price: 0,
            desc: "Kızarıklık ve hassasiyet hissini azaltmaya yönelik nazik protokol.",
            img: IMG.calm,
            category: "targetedCare",
            href: DETAIL_BASE + "sensitive-soothe#targetedCare",
            cart: { id: "skincare_sensitive", name: "Hassas Cilt Sakinleştirici Bakım", price: 0, cat: "skincare" },
        },
        {
            id: "barrier-repair",
            title: "Bariyer Onarıcı Bakım",
            duration: "55 dk",
            tier: "REPAIR",
            price: 0,
            desc: "Kuruluk ve gerginlik için destek — cilt bariyerini güçlendirmeye yardımcı.",
            img: IMG.hydrate,
            category: "targetedCare",
            href: DETAIL_BASE + "barrier-repair#targetedCare",
            cart: { id: "skincare_barrier", name: "Bariyer Onarıcı Bakım", price: 0, cat: "skincare" },
        },
        // MICRO / POLISH (non-medical, aesthetic)
        {
            id: "micro-polish",
            title: "Micro Polish Bakımı",
            duration: "45 dk",
            tier: "POLISH",
            price: 0,
            desc: "Cilt yüzeyini pürüzsüzleştiren bakım — daha canlı bir bitiş.",
            img: IMG.base,
            category: "advancedAesthetics",
            href: DETAIL_BASE + "micro-polish#advancedAesthetics",
            cart: { id: "skincare_micropolish", name: "Micro Polish Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "gold-mask-ritual",
            title: "Gold Mask Ritüeli",
            duration: "60 dk",
            tier: "LUXE",
            price: 0,
            desc: "Lüks maske + masaj — ışıl ışıl, dinlenmiş görünüm.",
            img: IMG.luxe,
            category: "advancedAesthetics",
            href: DETAIL_BASE + "gold-mask-ritual#advancedAesthetics",
            cart: { id: "skincare_gold", name: "Gold Mask Ritüeli", price: 0, cat: "skincare" },
        },
        // TARGETED MINI PROGRAMS
        {
            id: "eye-contour",
            title: "Göz Çevresi Bakımı",
            duration: "25 dk",
            tier: "EYE",
            price: 0,
            desc: "Göz çevresine yoğun nem ve rahatlama — daha canlı bakışlar.",
            img: IMG.hydrate,
            category: "miniPrograms",
            href: DETAIL_BASE + "eye-contour#miniPrograms",
            cart: { id: "skincare_eye", name: "Göz Çevresi Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "lip-care",
            title: "Dudak Bakımı",
            duration: "20 dk",
            tier: "LIP",
            price: 0,
            desc: "Yumuşatma + bakım — pürüzsüz ve dolgun görünüm hissi.",
            img: IMG.glow,
            category: "miniPrograms",
            href: DETAIL_BASE + "lip-care#miniPrograms",
            cart: { id: "skincare_lip", name: "Dudak Bakımı", price: 0, cat: "skincare" },
        },
        {
            id: "men-facial",
            title: "Erkek Cilt Bakımı",
            duration: "55 dk",
            tier: "MEN",
            price: 0,
            desc: "Tıraş sonrası hassasiyete uygun — temiz, dengeli ve net görünüm.",
            img: IMG.base,
            category: "miniPrograms",
            href: DETAIL_BASE + "men-facial#miniPrograms",
            cart: { id: "skincare_men", name: "Erkek Cilt Bakımı", price: 0, cat: "skincare" },
        },
    ];

    // Category labels (optional)
    window.NV_SKINCARE_CATEGORY_LABELS = {
        classicFacials: "CLASSIC FACIALS",
        hydrationGlow: "HYDRATION & GLOW",
        antiAgingLift: "ANTI-AGING & LIFT",
        targetedCare: "TARGETED CARE",
        advancedAesthetics: "ADVANCED AESTHETICS",
        miniPrograms: "MINI PROGRAMS",
    };

    window.NV_SKINCARE_PRICE_LABEL = function (price) {
        return !price ? "Fiyat sorunuz" : `${price}€`;
    };

    // Placeholder Guard
    window.NV_SKINCARE.forEach(item => {
        const imgCheck = new Image();
        imgCheck.onerror = () => {
            item.img = "/assets/img/luxury-placeholder.webp";
        };
        imgCheck.src = item.img;
    });

    console.log("✅ Skincare Data Loaded (Quiet Luxury Mode - Path Adjusted)");
})();
