// assets/js/hammam-ui.js
// Chip + Search + Grid (Masaj/Cilt bakımı mantığı) — price göstermez.

(function () {
    const SHOW_PRICE = false; // "fiyat yok" => kapalı

    const normalize = (s) =>
        (s || "")
            .toString()
            .toLowerCase()
            .replace(/\s+/g,
                " ")
            .trim();

    function buildHref(item) {
        // Eğer ileride özel hamam detay sayfası yaparsan item.href verirsin.
        if (item && item.href) return item.href;
        const slug = item.slug || item.id;
        return `/service-detail.html?slug=${encodeURIComponent(slug)}`;
    }

    function renderChips(chipsEl, activeKey, labels, orderKeys) {
        chipsEl.innerHTML = "";

        orderKeys.forEach((key) => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "nv-chip" + (key === activeKey ? " active" : "");
            btn.dataset.key = key;
            btn.textContent = labels[key
            ] || key;
            chipsEl.appendChild(btn);
        });
    }

    function renderCards(listEl, items) {
        // Grid görünümü garantile (bazı sayfalarda class farklı olabiliyor)
        listEl.classList.add("grid-cards");

        if (!items.length) {
            listEl.innerHTML = `
        <div style="opacity:.75; padding:24px; border:1px solid rgba(255,255,255,.08); border-radius:14px;">
          Sonuç bulunamadı.
        </div>
      `;
            return;
        }

        listEl.innerHTML = items
            .map((item) => {
                const href = buildHref(item);
                const duration = item.duration ? item.duration : "";
                const footerLeft = SHOW_PRICE ? `${duration
                    } / Fiyat sorunuz` : duration;

                return `
          <a class="card nv-card" href="${href}" style="text-decoration:none;">
            <div class="card-img-wrap">
              <img src="${item.img}" alt="${item.title}" loading="lazy" decoding="async">
            </div>
            <div class="card-content">
              <div style="display:flex; justify-content:space-between; align-items:center; gap:12px;">
                <h3 class="card-title" style="margin:0;">${item.title
                    }</h3>
                ${item.badge
                        ? `<span class="badge badge-popular" style="font-size:10px; padding:6px 10px; border-radius:999px;">${item.badge
                        }</span>`
                        : ""
                    }
              </div>
              <p style="margin:10px 0 0; color:rgba(255,255,255,.7); line-height:1.6;">
                ${item.excerpt || ""
                    }
              </p>
              <div class="card-footer" style="margin-top:14px;">
                <span>${footerLeft
                    }</span>
                <span>İncele &rarr;</span>
              </div>
            </div>
          </a>
        `;
            })
            .join("");
    }

    function initHammamUI() {
        const data = Array.isArray(window.NV_HAMMAM) ? window.NV_HAMMAM : [];
        const labels = window.NV_HAMMAM_CATEGORY_LABELS || {};
        const orderKeys = window.NV_HAMMAM_CATEGORY_ORDER || [
            "all",
            "foam_basic",
            "peeling_foam",
            "care_foam",
            "ottoman_program",
        ];

        const searchEl = document.getElementById("nvSearch");
        const chipsEl = document.getElementById("nvChips");
        const listEl = document.getElementById("nvList");

        if (!chipsEl || !listEl) return;

        let activeKey = "all";
        let query = "";

        const apply = () => {
            const q = normalize(query);

            const filtered = data
                .slice()
                .filter((item) => {
                    if (activeKey !== "all" && item.category !== activeKey) return false;

                    if (!q) return true;
                    const hay = normalize(
                        [
                            item.title,
                            item.excerpt,
                            (item.tags || []).join(" "),
                            item.badge,
                        ].join(" ")
                    );
                    return hay.includes(q);
                })
                .sort((a, b) => (a.order ?? 9999) - (b.order ?? 9999));

            renderCards(listEl, filtered);
        };

        renderChips(chipsEl, activeKey, labels, orderKeys);
        apply();

        chipsEl.addEventListener("click", (e) => {
            const btn = e.target.closest("button[data-key]");
            if (!btn) return;
            activeKey = btn.dataset.key || "all";
            renderChips(chipsEl, activeKey, labels, orderKeys);
            apply();
        });

        if (searchEl) {
            searchEl.addEventListener("input", (e) => {
                query = e.target.value || "";
                apply();
            });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initHammamUI);
    } else {
        initHammamUI();
    }
})();
