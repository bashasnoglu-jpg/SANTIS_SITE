/**
 * SANTIS CLUB — MASTER ENGINE v3.2 (STABLE / PRODUCTION)
 * Features: Race-Condition Fix, Ghost Slug Guard, 404 Handling, SEO Canonical
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. RACE-CONDITION FIX: Veri setleri yüklendi mi kontrol et.
    if (typeof window.NV_HAMMAM === 'undefined' && typeof window.NV_MASSAGES === 'undefined') {
        console.error("⚠️ Santis Critical: Data files not loaded yet. Retrying...");
        // Veri geç gelirse diye küçük bir tolerans tanı
        setTimeout(() => SANTIS_ENGINE.init(), 500);
        return;
    }

    SANTIS_ENGINE.init();
});

const SANTIS_ENGINE = {
    config: {
        whatsapp: "905348350169",
        placeholderImg: "assets/img/luxury-placeholder.webp",
        detailPage: "service-detail.html"
    },

    init() {
        console.log("🏆 Santis Engine v3.2: System Active.");
        this.pathResolver(); // Linkleri düzelt
        this.runDetailEngine(); // Detay sayfasını yönet
        this.setupImageGuard(); // Kırık resimleri yakala
    },

    // A. Link Harmonizer (Tüm kart tıklamalarını yönetir)
    pathResolver() {
        document.body.addEventListener('click', (e) => {
            const card = e.target.closest('.nv-card');
            if (card) {
                // Linkin içindeki slug'ı veya data-slug'ı al
                let slug = card.dataset.slug;
                if (!slug && card.getAttribute('href').includes('=')) {
                    slug = card.getAttribute('href').split('=')[1];
                }

                if (slug) {
                    e.preventDefault();
                    window.location.href = `${this.config.detailPage}?slug=${slug}`;
                }
            }
        });
    },

    // B. The Detail Core
    runDetailEngine() {
        if (!document.getElementById('santis-detail-root')) return;

        const params = new URLSearchParams(window.location.search);
        const slug = params.get('slug');

        // GHOST SLUG KORUMASI: Slug yoksa ana sayfaya at
        if (!slug) {
            console.warn("Ghost Slug Detected. Redirecting home...");
            window.location.replace('index.html');
            return;
        }

        // Veri Havuzu
        const allData = [
            ...(window.NV_HAMMAM || []),
            ...(window.NV_MASSAGES || []),
            ...(window.NV_SKINCARE || [])
        ];

        const item = allData.find(s => s.slug === slug || s.id === slug);

        // 404 KORUMASI
        if (!item) {
            this.render404();
            return;
        }

        this.renderPage(item);
        this.injectSEO(item);
    },

    renderPage(data) {
        document.title = `${data.title} | Santis Club`;

        // Text Injection
        const map = {
            'dynamic-title': data.title,
            'dynamic-kicker': `${data.tier || 'SIGNATURE'} • ${data.duration}`,
            'dynamic-desc': data.desc,
            'dynamic-long-desc': data.desc, // Varsa longDesc kullan
            'dynamic-duration': data.duration,
            'dynamic-price': data.price ? `${data.price}€` : "Fiyat sorunuz"
        };

        for (const [id, val] of Object.entries(map)) {
            const el = document.getElementById(id);
            if (el) el.innerText = val;
        }

        // Image Handling
        const bg = document.getElementById('dynamic-bg');
        if (bg) bg.style.backgroundImage = `url(${data.img})`;

        // Concierge Logic
        const cBtn = document.getElementById('concierge-btn');
        if (cBtn) {
            cBtn.onclick = () => {
                const msg = encodeURIComponent(`Merhaba Santis Concierge,\n\n[${data.title}] ritüeli için bilgi almak istiyorum.`);
                window.open(`https://wa.me/${this.config.whatsapp}?text=${msg}`, '_blank');
            };
        }

        // Cart Logic
        const cartBtn = document.getElementById('add-to-cart-btn');
        if (cartBtn) {
            cartBtn.onclick = () => {
                if (window.CART) window.CART.add(data.id);
                else alert("Sepet modülü bekleniyor...");
            };
        }
    },

    render404() {
        document.getElementById('dynamic-title').innerText = "Arşivde Bulunamadı";
        document.getElementById('dynamic-desc').innerText = "Aradığınız ritüel güncellenmiş veya kaldırılmış olabilir.";
        document.getElementById('dynamic-kicker').style.color = 'red';
        document.getElementById('dynamic-kicker').innerText = "404 HATA";

        const cBtn = document.getElementById('concierge-btn');
        if (cBtn) {
            cBtn.innerText = "ANA SAYFAYA DÖN";
            cBtn.onclick = () => window.location.href = 'index.html';
        }
        const cartBtn = document.getElementById('add-to-cart-btn');
        if (cartBtn) cartBtn.style.display = 'none';
    },

    injectSEO(data) {
        // Canonical Link Ekle
        let link = document.querySelector("link[rel='canonical']");
        if (!link) {
            link = document.createElement('link');
            link.rel = 'canonical';
            document.head.appendChild(link);
        }
        link.href = window.location.href;

        // Schema Ekle
        const schema = {
            "@context": "https://schema.org/",
            "@type": "Service",
            "name": data.title,
            "provider": {
                "@type": "LocalBusiness",
                "name": "Santis Club Spa"
            },
            "offers": {
                "@type": "Offer",
                "priceCurrency": "EUR",
                "price": data.price || "0"
            }
        };
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.text = JSON.stringify(schema);
        document.head.appendChild(script);
    },

    setupImageGuard() {
        document.addEventListener('error', (e) => {
            if (e.target.tagName === 'IMG') {
                e.target.src = this.config.placeholderImg;
                e.target.style.opacity = '0.5';
            }
        }, true);
    }
};
