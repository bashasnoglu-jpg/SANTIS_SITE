/* SANTIS CLUB - MASSAGE DATA (Root Path Fixed) */
window.NV_MASSAGES = [
    {
        id: "klasik-rahatlama",
        slug: "klasik-rahatlama",
        title: "Klasik Rahatlama Masajı",
        // DİKKAT: Başında / işareti var!
        img: "/assets/img/cards/hamam.webp",
        desc: "İsveç tekniğiyle uygulanan, kasları gevşeten orta baskılı terapi.",
        price: 80,
        duration: "50 dk",
        tier: "CLASSIC",
        category: "classicMassages"
    },
    {
        id: "bali",
        slug: "bali",
        title: "Geleneksel Bali Masajı",
        // DİKKAT: Başında / işareti var!
        img: "/assets/img/cards/hamam.webp",
        desc: "Avuç içi ve parmak baskılarıyla yapılan, enerji akışını dengeleyen uzak doğu ritüeli.",
        price: 90,
        duration: "50 dk",
        tier: "SIGNATURE",
        category: "asianMassages"
    },
    {
        id: "thai",
        slug: "thai",
        title: "Thai Masajı",
        // DİKKAT: Başında / işareti var!
        img: "/assets/img/cards/hamam.webp",
        desc: "Yağsız uygulanan, esnetme ve germe hareketleriyle vücut esnekliğini artıran 'Tembel Yogası'.",
        price: 100,
        duration: "60 dk",
        tier: "THERAPY",
        category: "asianMassages"
    },
    {
        id: "derin-doku",
        slug: "derin-doku",
        title: "Derin Doku (Deep Tissue)",
        // DİKKAT: Başında / işareti var!
        img: "/assets/img/cards/hamam.webp",
        desc: "Kronik ağrılar ve sertleşmiş kaslar için uygulanan sert baskılı, tedavi edici masaj.",
        price: 110,
        duration: "50 dk",
        tier: "INTENSE",
        category: "sportsTherapy"
    },
    {
        id: "aromaterapi",
        slug: "aromaterapi",
        title: "Aromaterapi Masajı",
        duration: "50 dk",
        price: null,
        desc: "Doğal uçucu yağlarla yapılan, duyuları dengeleyen ve derin rahatlama sağlayan ritüel.",
        img: "/assets/img/cards/hamam.webp",
        category: "classicMassages",
        tags: ["aroma", "rahatlama", "uyku"],
        tier: "AROMA"
    },
    {
        id: "sicak-tas",
        slug: "sicak-tas",
        title: "Sıcak Taş Masajı",
        duration: "75 dk",
        price: null,
        desc: "Isıtılmış taşlarla kas gerginliğini hedefleyen ve rahatlama sağlayan terapi.",
        img: "/assets/img/cards/hamam.webp",
        category: "classicMassages",
        tags: ["sıcak", "gevşeme", "dolaşım"],
        tier: "STONE"
    },
    {
        id: "bas-boyun-omuz",
        slug: "bas-boyun-omuz",
        title: "Baş–Boyun–Omuz Masajı",
        duration: "30 dk",
        price: null,
        desc: "Bölgesel gerginliklere odaklanan, yorgunluğu hafifletmeyi hedefleyen ekspres bakım.",
        img: "/assets/img/cards/hamam.webp",
        category: "classicMassages",
        tags: ["boyun", "ofis", "kısa"],
        tier: "EXPRESS"
    },
    {
        id: "spor-terapi",
        slug: "spor-terapi",
        title: "Spor Terapi Masajı",
        duration: "50 dk",
        price: null,
        desc: "Aktif yaşam stiline özel; toparlanmayı destekleyen ve esnekliği artıran protokol.",
        img: "/assets/img/cards/hamam.webp",
        category: "sportsTherapy",
        tags: ["toparlanma", "performans", "aktif"],
        tier: "SPORT"
    },
    {
        id: "sirt-terapi",
        slug: "sirt-terapi",
        title: "Sırt Odaklı Terapi",
        duration: "30 dk",
        price: null,
        desc: "Sırt bölgesindeki gerginliği hedefleyen, duruş kaynaklı yorgunluğa iyi gelen odaklı çalışma.",
        img: "/assets/img/cards/hamam.webp",
        category: "sportsTherapy",
        tags: ["sırt", "gerginlik", "duruş"],
        tier: "BACK"
    },
    {
        id: "shiatsu",
        slug: "shiatsu",
        title: "Shiatsu",
        duration: "50 dk",
        price: null,
        desc: "Parmak baskısıyla vücuttaki enerji akışını dengelemeyi amaçlayan teknik.",
        img: "/assets/img/cards/hamam.webp",
        category: "asianMassages",
        tags: ["shiatsu", "baskı", "enerji"],
        tier: "JAPAN"
    },
    {
        id: "cift-senkron",
        slug: "cift-senkron",
        title: "Çift Masajı (Senkron)",
        duration: "50 dk",
        price: null,
        desc: "İki terapist tarafından aynı anda uygulanan, eş zamanlı rahatlama deneyimi.",
        img: "/assets/img/cards/hamam.webp",
        category: "signatureCouples",
        tags: ["çift", "senkron", "romantik"],
        tier: "DUO"
    },
    {
        id: "signature-rituel",
        slug: "signature-rituel",
        title: "Signature Santis Ritüeli",
        duration: "75 dk",
        price: null,
        desc: "Doğu ve Batı tekniklerinin en iyi kombinasyonuyla oluşturulan özel imza masajımız.",
        img: "/assets/img/cards/hamam.webp",
        category: "signatureCouples",
        tags: ["signature", "premium", "özel"],
        tier: "SIGNATURE"
    },
    {
        id: "cift-rituel",
        slug: "cift-rituel",
        title: "Çift Spa Ritüeli (Masaj + Bakım)",
        duration: "90 dk",
        price: null,
        desc: "Çiftlere özel masaj ve bakım kombinasyonu. Birlikte yenilenin.",
        img: "/assets/img/cards/hamam.webp",
        category: "signatureCouples",
        tags: ["çift", "paket", "romantik"],
        tier: "VIP_COUPLE"
    },
    {
        id: "kids-nazik",
        slug: "kids-nazik",
        title: "Kids Masajı (Nazik Dokunuş)",
        duration: "30 dk",
        price: null,
        desc: "Çocuklara özel, çok hafif baskılı ve eğlenceli, rahatlatıcı masaj deneyimi.",
        img: "/assets/img/cards/hamam.webp",
        category: "kidsFamily",
        tags: ["kids", "nazik", "çocuk"],
        tier: "JUNIOR"
    },
    {
        id: "anne-cocuk",
        slug: "anne-cocuk",
        title: "Anne–Çocuk Rahatlama",
        duration: "50 dk",
        price: null,
        desc: "Anne ve çocuk için aynı odada, güvenli ve keyifli bir spa anısı.",
        img: "/assets/img/cards/hamam.webp",
        category: "kidsFamily",
        tags: ["family", "birlikte", "anne"],
        tier: "FAMILY"
    }
];

// Placeholder Koruma (Resim yüklenmezse devreye girer)
window.NV_MASSAGES.forEach(item => {
    const imgCheck = new Image();
    imgCheck.onerror = () => {
        // Eğer resim bulunamazsa varsayılan görseli ata
        item.img = "/assets/img/luxury-placeholder.webp";
        // console.warn(`Resim Bulunamadı: ${item.title}`);
    };
    imgCheck.src = item.img;
});
